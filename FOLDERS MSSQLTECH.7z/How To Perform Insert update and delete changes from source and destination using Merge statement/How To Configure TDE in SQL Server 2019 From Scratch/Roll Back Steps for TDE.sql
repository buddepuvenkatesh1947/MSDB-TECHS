--Roll back up steps For TDE

--Step1:
Use dba
Go
Alter Database dba Set Encryption off 

--Step2:
Use dba
go
Drop database encryption key 

--Step3:
Use Master
Go
Drop certificate TDE_Certificate

--Step4:--Optional
Use master
Go
Drop master key 